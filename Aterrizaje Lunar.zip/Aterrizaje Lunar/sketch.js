let ground,lander;
var lander_img,bg_img;
var vx=0;
var vy=0;
var g=0.05;

function preload(){
    lander_img=loadImage("normal.png")
    bg_img = loadImage("bg.png")
}

function setup(){
    createCanvas(1000,700)
    frameRate(80)
    lander= createSprite(100,50,30,30)
    lander.addImage(lander_img)
    lander.scale = 0.1

    rectMode(CENTER)
    textSize(15)
}

function draw(){
    background(51)
    image(bg_img,0,0)
    push()
    fill(255)
    text("velocidad vertical"+round(vy),800,75)
    pop()

    //Caida
vy+=g
lander.position.y+=vy
drawSprites()
}